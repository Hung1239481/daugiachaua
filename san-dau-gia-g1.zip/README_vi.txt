📘 Hướng dẫn chạy demo G1 - Sàn Đấu Giá Châu Á - V1

1. Cài Python 3.10 trở lên
2. Tạo môi trường ảo:
   python -m venv venv
   venv\Scripts\activate  (hoặc source venv/bin/activate nếu dùng Linux)
3. Cài thư viện:
   pip install -r requirements.txt
4. Chạy server:
   python manage.py runserver

👉 Trang đăng nhập: http://127.0.0.1:8000/login/
👉 Trang đăng ký: http://127.0.0.1:8000/register/
